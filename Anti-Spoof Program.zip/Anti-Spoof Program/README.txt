***************************************README******************************************

The following folder contains:-

1)main.py

2)l_version_1_20.pt

**************************************************************************************

The main.py contains the code for the implementation and l_version_1_20.pt contains the trained MACHINE LEARNING MODEL.

The user should install both files and ADD PATHS accordingly.

****************************************************************************************

Contact Devlopers through website for further assistance.